package avance2;

import javax.swing.*;

public class ReservaciondeEspacios {

    private int dias;
    private int personas;
    private double tarifaEntreSemana;
    private double tarifaFinDeSemana;

    public ReservaciondeEspacios() {
        this.dias = 0;
        this.personas = 0;
        this.tarifaEntreSemana = 80.0;
        this.tarifaFinDeSemana = 100.0;
    }

    public void solicitarInformacion() {
        String input = JOptionPane.showInputDialog(null, "Ingrese la cantidad de días que desea reservar:");
        this.dias = Integer.parseInt(input);

        input = JOptionPane.showInputDialog(null, "Ingrese la cantidad de personas:");
        this.personas = Integer.parseInt(input);
    }

    public boolean verificarDisponibilidad() {
     
        return true;
    }

    public double calcularMontoAPagar() {
        double tarifaPorPersonaPorNoche = esFinDeSemana() ? tarifaFinDeSemana : tarifaEntreSemana;

        double montoSinIVA = tarifaPorPersonaPorNoche * this.personas * this.dias;
        double iva = montoSinIVA * 0.12; // IVA del 12%
        double montoTotal = montoSinIVA + iva;

        return montoTotal;
    }

    private boolean esFinDeSemana() {
        
        return false;
    }
}
