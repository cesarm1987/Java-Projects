package avance2;

import javax.swing.JOptionPane;


public class RegistrodelVehiculo {
   
    private String numeroPlaca;
    private String formaPago;
    private int tiempoParqueo;

    public void solicitarDatos() {
        // Solicitar número de placa
        numeroPlaca = JOptionPane.showInputDialog("Ingrese el número de placa del vehículo:");

        // Solicitar forma de pago
        String[] opcionesPago = {"Efectivo", "Transferencia", "Tarjeta de crédito"};
        int formaPagoIndex = JOptionPane.showOptionDialog(null, "Seleccione la forma de pago:", "Forma de Pago", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opcionesPago, opcionesPago[0]);

        formaPago = opcionesPago[formaPagoIndex];

        // Solicitar tiempo estimado de parqueo
        String tiempoParqueoStr = JOptionPane.showInputDialog("Ingrese el tiempo estimado de parqueo en minutos:");
        tiempoParqueo = Integer.parseInt(tiempoParqueoStr);
    }

    public void mostrarDatos() {
        // Mostrar los datos ingresados
        String mensaje = "Registro de Vehículo\n";
        mensaje += "Número de placa: " + numeroPlaca + "\n";
        mensaje += "Forma de pago: " + formaPago + "\n";
        mensaje += "Tiempo estimado de parqueo: " + tiempoParqueo + " minutos";

        JOptionPane.showMessageDialog(null, mensaje);
    }
   
}