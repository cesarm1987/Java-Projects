//Parqueo “El descanso”
//Grupo 19 POO II Cuatrimestre 2023
//Apellidos: Morera,Muñoz,Nuñez,Peraza 

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

// Clase Parqueo
class Parqueo {
    private final String ubicacion;
    private List<Vehiculo> vehiculos;
    private List<EspacioReservado> reservacionesEspacios;
    private List<Mensualidad> reservacionesMensuales;

    // Constructor
    public Parqueo(String ubicacion) {
        this.ubicacion = ubicacion;
        this.vehiculos = new ArrayList<>();
        this.reservacionesEspacios = new ArrayList<>();
        this.reservacionesMensuales = new ArrayList<>();
    }

    // Métodos

    // Registramos un vehículo en el parqueo
    public void registrarVehiculo(Vehiculo vehiculo) {
        vehiculos.add(vehiculo);
    }

    // Reservamos un espacio en el parqueo
    public void reservarEspacio(EspacioReservado espacio) {
        if (reservacionesEspacios.contains(espacio)) {
            mostrarMensaje("El espacio ya ha sido reservado.");
        } else if (verificarDisponibilidad(espacio)) {
            reservacionesEspacios.add(espacio);
            mostrarMensaje("Reservación de espacio realizada exitosamente.");
        } else {
            mostrarMensaje("No hay disponibilidad para el espacio solicitado.");
        }
    }

    // Reservamos una mensualidad en el parqueo
    public void reservarMensualidad(Mensualidad mensualidad) {
        reservacionesMensuales.add(mensualidad);
        mostrarMensaje("Reservación mensual realizada exitosamente.");
    }

    // Generamos un reporte de ocupación mensual del parqueo
    public String generarReporteOcupacion() {
        StringBuilder reporte = new StringBuilder();
        reporte.append("Reporte de ocupación mensual:\n");
        reporte.append("----------------------------\n");

        reporte.append("Reservaciones de Espacios:\n");
        for (EspacioReservado espacio : reservacionesEspacios) {
            reporte.append("Fecha inicio: ").append(espacio.getFechaInicio()).append("\n");
            reporte.append("Fecha fin: ").append(espacio.getFechaFin()).append("\n");
            reporte.append("--------------------\n");
        }

        reporte.append("Reservaciones Mensuales:\n");
        for (Mensualidad mensualidad : reservacionesMensuales) {
            reporte.append("Días: ").append(mensualidad.getDias()).append("\n");
            reporte.append("Tiempo: ").append(mensualidad.getTiempo()).append("\n");
            reporte.append("--------------------\n");
        }

        return reporte.toString();
    }

    // Verificamos la disponibilidad de un espacio en el parqueo
    private boolean verificarDisponibilidad(EspacioReservado espacio) {
        return true; // Lógica de verificación de disponibilidad
    }

    // Mostramos un mensaje en una ventana emergente
    private void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje);
    }
}

// Clase Vehiculo
class Vehiculo {
    private final String numeroPlaca;
    private final String formaPago;
    private final int tiempoEstimado;

    // Constructor
    public Vehiculo(String numeroPlaca, String formaPago, int tiempoEstimado) {
        this.numeroPlaca = numeroPlaca;
        this.formaPago = formaPago;
        this.tiempoEstimado = tiempoEstimado;
    }

    // Getters y setters...
}

// Clase EspacioReservado
class EspacioReservado {
    private final String fechaInicio;
    private final String fechaFin;

    // Constructor
    public EspacioReservado(String fechaInicio, String fechaFin) {
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    // Getters
    public String getFechaInicio() {
        return fechaInicio;
    }

    public String getFechaFin() {
        return fechaFin;
    }
}

// Clase Mensualidad
class Mensualidad {
    private final String dias;
    private final String tiempo;

    // Constructor
    public Mensualidad(String dias, String tiempo) {
        this.dias = dias;
        this.tiempo = tiempo;
    }

    // Getters
    public String getDias() {
        return dias;
    }

    public String getTiempo() {
        return tiempo;
    }
}

// Clase ParqueoApp (Clase principal)
public class ParqueoApp {
    public static void main(String[] args) {
        // Solicitamos la ubicación del parqueo al usuario
        String ubicacion = JOptionPane.showInputDialog(null, "Ingrese la ubicación del parqueo:");
        Parqueo parqueo = new Parqueo(ubicacion);

        // Solicitamos la cantidad de vehículos a registrar al usuario
        int numeroVehiculos = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la cantidad de vehículos a registrar:"));
        for (int i = 1; i <= numeroVehiculos; i++) {
            // Solicitamos los datos de cada vehículo al usuario
            String numeroPlaca = JOptionPane.showInputDialog(null, "Ingrese el número de placa del vehículo " + i + ":");
            String formaPago = JOptionPane.showInputDialog(null, "Ingrese la forma de pago del vehículo " + i + ":");
            int tiempoEstimado = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el tiempo estimado de parqueo del vehículo " + i + ":"));
            Vehiculo vehiculo = new Vehiculo(numeroPlaca, formaPago, tiempoEstimado);
            parqueo.registrarVehiculo(vehiculo);
        }

        // Solicitamos las fechas de inicio y fin de la reservación de espacio al usuario
        String fechaInicio = JOptionPane.showInputDialog(null, "Ingrese la fecha de inicio de la reservación:");
        String fechaFin = JOptionPane.showInputDialog(null, "Ingrese la fecha de fin de la reservación:");
        EspacioReservado espacio = new EspacioReservado(fechaInicio, fechaFin);
        parqueo.reservarEspacio(espacio);

        // Solicitamos los días y tiempo de la reservación mensual al usuario
        String diasMensualidad = JOptionPane.showInputDialog(null, "Ingrese los días de la reservación mensual:");
        String tiempoMensualidad = JOptionPane.showInputDialog(null, "Ingrese el tiempo de la reservación mensual:");
        Mensualidad mensualidad = new Mensualidad(diasMensualidad, tiempoMensualidad);
        parqueo.reservarMensualidad(mensualidad);

        // Generamos el reporte de ocupación y mostrarlo en una ventana emergente
        String reporteOcupacion = parqueo.generarReporteOcupacion();
        JOptionPane.showMessageDialog(null, reporteOcupacion);

        // Mostramos mensaje de despedida y finalizar el programa
        JOptionPane.showMessageDialog(null, "Gracias por utilizar el sistema de parqueo el descanso. ¡Hasta la próxima!");
        System.exit(0);
    }
}
