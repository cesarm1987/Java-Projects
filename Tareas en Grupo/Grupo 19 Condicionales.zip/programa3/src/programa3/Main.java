/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programa3;

/**
 *
 * @author Grupo19
 */
/*Programa para determinar si un carácter ingresado por teclado es una letra mayúscula*/

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        /*Ingreso de la letra*/
        String input = JOptionPane.showInputDialog("Ingrese un carácter:");
        char caracter = input.charAt(0);
        
        if (Character.isUpperCase(caracter)) {
            JOptionPane.showMessageDialog(null, "Es una letra mayúscula.");
        } else {
            JOptionPane.showMessageDialog(null, "No es una letra mayúscula.");
        }
    }
}
