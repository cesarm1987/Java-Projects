/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programa1;

/**
 *
 * @author cesar
 */
/*Programa para determinar si un número entero es par o impar*/

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        /*Ingreso de valores numerales*/
        String input = JOptionPane.showInputDialog("Ingrese un número entero:");
        int numero = Integer.parseInt(input);
        
        if (numero % 2 == 0) {
            JOptionPane.showMessageDialog(null, "El número es par.");
        } else {
            JOptionPane.showMessageDialog(null, "El número es impar.");
        }
    }
}
