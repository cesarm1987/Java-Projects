/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programa2;

/**
 *
 * @author Grupo19
 */
/*Programa para determinar si un número entero es múltiplo de 10*/

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        /*Ingrese los números*/
        String input = JOptionPane.showInputDialog("Ingrese un número entero:");
        int numero = Integer.parseInt(input);
        
        if (numero % 10 == 0) {
            JOptionPane.showMessageDialog(null, "El número es múltiplo de 10.");
        } else {
            JOptionPane.showMessageDialog(null, "El número no es múltiplo de 10.");
        }
    }
}
