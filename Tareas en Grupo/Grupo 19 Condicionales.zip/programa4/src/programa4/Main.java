/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programa4;

/**
 *
 * @author Grupo19
 */
/*Programa para solicitar tres números y mostrarlos ordenados de mayor a menor*/

import java.util.Arrays;
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        /*Operaciones matematicas*/
        int[] numeros = new int[3];
        
        /*Utilizamos un bucle for para solicitar al usuario que ingrese tres números y almacenarlos en un arreglo llamado numeros.*/
        for (int i = 0; i < 3; i++) {
            String input = JOptionPane.showInputDialog("Ingrese el número " + (i + 1) + ":");
            numeros[i] = Integer.parseInt(input);
        }
        
        Arrays.sort(numeros);
        
        StringBuilder resultado = new StringBuilder();
        resultado.append("Números ordenados de mayor a menor:\n");
        for (int i = 2; i >= 0; i--) {
            resultado.append(numeros[i]).append("\n");
        }
        
        JOptionPane.showMessageDialog(null, resultado.toString());
    }
}
