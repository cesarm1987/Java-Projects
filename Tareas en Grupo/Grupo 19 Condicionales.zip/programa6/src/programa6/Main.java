/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programa6;

/**
 *
 * @author Grupo19
 */
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        /*Ingremos lo valores de cilindro*/
        String inputRadio = JOptionPane.showInputDialog("Ingrese el radio del cilindro:");
        double radio = Double.parseDouble(inputRadio);
        
        String inputAltura = JOptionPane.showInputDialog("Ingrese la altura del cilindro:");
        double altura = Double.parseDouble(inputAltura);
        
        /*Realizamos las operaciones matematicas*/
        double area = 2 * Math.PI * radio * altura;
        double volumen = Math.PI * Math.pow(radio, 2) * altura;
        
        
        StringBuilder resultado = new StringBuilder();
        resultado.append("Área del cilindro: ").append(area).append("\n");
        resultado.append("Volumen del cilindro: ").append(volumen).append("\n");
        
        JOptionPane.showMessageDialog(null, resultado.toString());
    }
}
