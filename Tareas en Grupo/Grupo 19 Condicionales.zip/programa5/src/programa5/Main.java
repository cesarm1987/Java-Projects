/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programa5;

/**
 *
 * @author Grupo19
 */
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        String input = JOptionPane.showInputDialog("Ingrese el monto de compra:");
        double montoCompra = Double.parseDouble(input);
        
        /*Ingreso de operadores matematicos*/
        double descuento = 0;
        if (montoCompra > 100) {
            descuento = 0.1 * montoCompra; // Descuento del 10% si el monto es mayor a 100
        }
        
        double montoPagar = montoCompra - descuento;
        
        StringBuilder resultado = new StringBuilder();
        resultado.append("Monto de compra: $").append(montoCompra).append("\n");
        resultado.append("Descuento: $").append(descuento).append("\n");
        resultado.append("Monto a pagar: $").append(montoPagar).append("\n");
        
        JOptionPane.showMessageDialog(null, resultado.toString());
    }
}
