/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programa1;

/**
 *
 * @author Grupo19
 */
import javax.swing.JOptionPane;

public class NumerosTicos {
    public static void main(String[] args) {
        mostrarNumerosDoWhile();
        mostrarNumerosWhile();
        mostrarNumerosFor();
    }

    private static void mostrarNumerosDoWhile() {
        int numero = 1;
        StringBuilder resultado = new StringBuilder();

        do {
            resultado.append(numero).append(" ");
            numero++;
        } while (numero <= 100);

        JOptionPane.showMessageDialog(null, "Números del 1 al 100 (do-while):\n" + resultado.toString());
    }

    private static void mostrarNumerosWhile() {
        int numero = 1;
        StringBuilder resultado = new StringBuilder();

        while (numero <= 100) {
            resultado.append(numero).append(" ");
            numero++;
        }

        JOptionPane.showMessageDialog(null, "Números del 1 al 100 (while):\n" + resultado.toString());
    }

    private static void mostrarNumerosFor() {
        StringBuilder resultado = new StringBuilder();

        for (int i = 1; i <= 100; i++) {
            resultado.append(i).append(" ");
        }

        JOptionPane.showMessageDialog(null, "Números del 1 al 100 (for):\n" + resultado.toString());
    }
}
