/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication15;

/**
 *
 * @author Grupo19
 */
import javax.swing.JOptionPane;

public class MiPrograma {
    public static void main(String[] args) {
        int contador = 0;
        int numero;

        do {
            // Leer el número ingresado por el usuario
            String input = JOptionPane.showInputDialog(null, "Ingrese un número (0 para salir):");
            numero = Integer.parseInt(input);

            // Verificar si el número termina en 2 y aumentar el contador
            if (numero % 10 == 2) {
                contador++;
            }
        } while (numero != 0);

        JOptionPane.showMessageDialog(null, "Se ingresaron " + contador + " números que terminan en 2.");
    }
}
