/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programa6;

/**
 *
 * @author Grupo19
 */
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        int productoPares = 1;
        int productoImpares = 1;

        for (int i = 1; i <= 10; i++) {
            if (i % 2 == 0) {
                productoPares *= i;
            } else {
                productoImpares *= i;
            }
        }

        String mensaje = "Producto de los números pares: " + productoPares + "\n"
                + "Producto de los números impares: " + productoImpares;

        JOptionPane.showMessageDialog(null, mensaje, "Productos", JOptionPane.INFORMATION_MESSAGE);
    }
}
