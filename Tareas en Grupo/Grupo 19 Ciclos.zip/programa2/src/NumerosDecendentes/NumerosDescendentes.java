/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package NumerosDecendentes;

/**
 *
 * @author mpaul
 */

import javax.swing.JOptionPane;

public class NumerosDescendentes {
    public static void main(String[] args) {
        StringBuilder numeros = new StringBuilder();

        // Iniciar desde 100 y decrementar hasta 1
        for (int i = 100; i >= 1; i--) {
            numeros.append(i).append(" ");
        }

        JOptionPane.showMessageDialog(null, numeros.toString(), "Números Descendentes", JOptionPane.INFORMATION_MESSAGE);
    }
}
