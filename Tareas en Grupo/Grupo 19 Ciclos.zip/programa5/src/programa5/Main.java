/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programa5;

/**
 *
 * @author Grupo19
 */
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        StringBuilder numeros = new StringBuilder();

        for (int i = 100; i >= 0; i -= 7) {
            numeros.append(i).append("\n");
        }

        JOptionPane.showMessageDialog(null, numeros.toString(), "Números de 7 en 7", JOptionPane.INFORMATION_MESSAGE);
    }
}
