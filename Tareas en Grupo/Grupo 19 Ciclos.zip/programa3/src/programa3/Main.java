/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programa3;

/**
 *
 * @author Grupo19
 */
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        int numero;

        do {
            // Leer el número ingresado por el usuario
            String input = JOptionPane.showInputDialog(null, "Ingrese un número (0 para salir):");
            numero = Integer.parseInt(input);

            // Verificar si el número es positivo o negativo
            if (numero > 0) {
                JOptionPane.showMessageDialog(null, "El número es positivo.");
            } else if (numero < 0) {
                JOptionPane.showMessageDialog(null, "El número es negativo.");
            } else {
                JOptionPane.showMessageDialog(null, "¡Hasta luego!");
            }
        } while (numero != 0);
    }
}
