package enunciado1;

/**
 *
 * @author Grupo19
 */
import javax.swing.JOptionPane;

public class Enunciado1 {
    public static void main(String[] args) {
        // Creamos una instancia de la clase Formula1Data para almacenar los tiempos de vuelta y PITS
        Formula1Data data = new Formula1Data();

        // Captura de tiempos de vuelta y PITS
        for (int i = 0; i < 10; i++) {
            data.setTiempoVuelta(i, Double.parseDouble(JOptionPane.showInputDialog("Ingrese el tiempo de la vuelta " + (i + 1) + " en segundos:")));
            data.setTiempoPITS(i, Double.parseDouble(JOptionPane.showInputDialog("Ingrese el tiempo en PITS " + (i + 1) + " en segundos:")));
        }

        // Cálculo del tiempo promedio por vuelta y por PITS
        double tiempoPromedioVuelta = data.calcularPromedioVuelta();
        double tiempoPromedioPITS = data.calcularPromedioPITS();

        // Cálculo del porcentaje de tiempo PITS respecto al tiempo de recorrido de una vuelta
        double porcentajePITS = (tiempoPromedioPITS / tiempoPromedioVuelta) * 100;

        // Mostrar resultados en JOptionPane
        JOptionPane.showMessageDialog(null, "El tiempo promedio por vuelta es de: " + tiempoPromedioVuelta + " segundos");
        JOptionPane.showMessageDialog(null, "El tiempo promedio por PITS es de: " + tiempoPromedioPITS + " segundos");
        JOptionPane.showMessageDialog(null, "El porcentaje del tiempo PITS respecto al tiempo de recorrido de una vuelta es de: " + porcentajePITS + "%");
    }
}

// Clase Formula1Data para encapsular los datos y la lógica relacionada
class Formula1Data {
    private double[] tiemposVuelta = new double[10];
    private double[] tiemposPITS = new double[10];

    // Getters y setters para los atributos tiemposVuelta y tiemposPITS
    public double getTiempoVuelta(int index) {
        return tiemposVuelta[index];
    }

    public void setTiempoVuelta(int index, double tiempo) {
        tiemposVuelta[index] = tiempo;
    }

    public double getTiempoPITS(int index) {
        return tiemposPITS[index];
    }

    public void setTiempoPITS(int index, double tiempo) {
        tiemposPITS[index] = tiempo;
    }

    // Método para calcular el promedio de los tiempos de vuelta
    public double calcularPromedioVuelta() {
        double suma = 0;
        for (double tiempo : tiemposVuelta) {
            suma += tiempo;
        }
        return suma / tiemposVuelta.length;
    }

    // Método para calcular el promedio de los tiempos de PITS
    public double calcularPromedioPITS() {
        double suma = 0;
        for (double tiempo : tiemposPITS) {
            suma += tiempo;
        }
        return suma / tiemposPITS.length;
    }
}
