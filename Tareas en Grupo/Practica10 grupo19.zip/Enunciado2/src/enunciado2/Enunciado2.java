package enunciado2;

/**
 *
 * @author Grupo19
 */
import javax.swing.JOptionPane;

public class Enunciado2 {
    public static void main(String[] args) {
        // Pedimos al usuario la cantidad de niños
        int cantidadNinos = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de niños:"));

        // Arreglos para almacenar las estaturas de los niños
        double[] estaturas = new double[cantidadNinos];

        // Captura de estaturas de los niños
        for (int i = 0; i < cantidadNinos; i++) {
            estaturas[i] = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la estatura del niño " + (i + 1) + " en centímetros:"));
        }

        // Variables para almacenar las cantidades de niños en cada rango de estaturas
        int cantidadMenos100 = 0;
        int cantidadEntre100y120 = 0;
        int cantidadEntre121y130 = 0;
        int cantidadEntre131y140 = 0;
        int cantidadMas140 = 0;

        // Variable para almacenar la suma de todas las estaturas
        double sumaEstaturas = 0;

        // Análisis de las estaturas y conteo de niños en cada rango
        for (double estatura : estaturas) {
            if (estatura < 100) {
                cantidadMenos100++;
            } else if (estatura >= 100 && estatura <= 120) {
                cantidadEntre100y120++;
            } else if (estatura >= 121 && estatura <= 130) {
                cantidadEntre121y130++;
            } else if (estatura >= 131 && estatura <= 140) {
                cantidadEntre131y140++;
            } else {
                cantidadMas140++;
            }

            // Sumamos la estatura al acumulador para calcular el promedio más adelante
            sumaEstaturas += estatura;
        }

        // Cálculo del promedio de estaturas
        double promedioEstaturas = sumaEstaturas / cantidadNinos;

        // Mostrar resultados en JOptionPane
        JOptionPane.showMessageDialog(null, "Cantidad de niños que miden menos de 100 cm: " + cantidadMenos100);
        JOptionPane.showMessageDialog(null, "Cantidad de niños que miden entre 100 y 120 cm: " + cantidadEntre100y120);
        JOptionPane.showMessageDialog(null, "Cantidad de niños que miden entre 121 y 130 cm: " + cantidadEntre121y130);
        JOptionPane.showMessageDialog(null, "Cantidad de niños que miden entre 131 y 140 cm: " + cantidadEntre131y140);
        JOptionPane.showMessageDialog(null, "Cantidad de niños que miden más de 140 cm: " + cantidadMas140);
        JOptionPane.showMessageDialog(null, "Promedio de estaturas: " + promedioEstaturas + " cm");

        // ¡Pura vida! ¡Hemos completado el programa!
    }
}
