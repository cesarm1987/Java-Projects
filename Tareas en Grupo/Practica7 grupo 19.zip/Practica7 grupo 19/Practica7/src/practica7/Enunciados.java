package practica7;

/**
 *
 * @author Grupo19
 * Enunciados 1 y 2
 */
import javax.swing.JOptionPane;

public class Enunciados {

    public static void main(String[] args) {
        // Enunciado 1: Invertir la mitad de los elementos de un vector

        // Obtener los elementos del vector del usuario
        String input = JOptionPane.showInputDialog("Ingrese los elementos del vector separados por coma:");
        String[] elementos = input.split(",\\s*");

        // Crear el vector de enteros
        int n = elementos.length;
        int[] vector = new int[n];

        // Llenar el vector
        for (int i = 0; i < n; i++) {
            vector[i] = Integer.parseInt(elementos[i].trim());
        }

        // Invertir la mitad de los elementos del vector
        int mitad = n / 2;
        for (int i = 0; i < mitad; i++) {
            int temp = vector[i];
            vector[i] = vector[n - i - 1];
            vector[n - i - 1] = temp;
        }

        // Mostrar el vector invertido
        String resultado = "Vector invertido:\n";
        for (int i = 0; i < n; i++) {
            resultado += vector[i] + " ";
        }

        JOptionPane.showMessageDialog(null, resultado);

        
        // Enunciado 2: Intercambiar el mínimo de una matriz con el máximo de otra matriz
        
        // Obtener los elementos de la matriz A del usuario
        String inputA = JOptionPane.showInputDialog("Ingrese los elementos de la matriz A separados por coma:");
        String[] elementosA = inputA.split(",\\s*");

        // Obtener los elementos de la matriz B del usuario
        String inputB = JOptionPane.showInputDialog("Ingrese los elementos de la matriz B separados por coma:");
        String[] elementosB = inputB.split(",\\s*");

        // Crear las matrices de enteros
        int m = elementosA.length;
        int n2 = elementosB.length;
        int[] matrizA = new int[m];
        int[] matrizB = new int[n2];

        // Llenar la matriz A
        for (int i = 0; i < m; i++) {
            matrizA[i] = Integer.parseInt(elementosA[i].trim());
        }

        // Llenar la matriz B
        for (int i = 0; i < n2; i++) {
            matrizB[i] = Integer.parseInt(elementosB[i].trim());
        }

        // Encontrar el mínimo de A y el máximo de B
        int minA = matrizA[0];
        int maxB = matrizB[0];
        for (int i = 0; i < m; i++) {
            if (matrizA[i] < minA) {
                minA = matrizA[i];
            }
        }
        for (int i = 0; i < n2; i++) {
            if (matrizB[i] > maxB) {
                maxB = matrizB[i];
            }
        }

        // Encontrar las posiciones del mínimo de A y el máximo de B
        int indiceMinA = -1;
        int indiceMaxB = -1;
        for (int i = 0; i < m; i++) {
            if (matrizA[i] == minA) {
                indiceMinA = i;
                break;
            }
        }
        for (int i = 0; i < n2; i++) {
            if (matrizB[i] == maxB) {
                indiceMaxB = i;
                break;
            }
        }

        // Intercambiar el mínimo de A con el máximo de B
        if (indiceMinA != -1 && indiceMaxB != -1) {
            int temp = matrizA[indiceMinA];
            matrizA[indiceMinA] = matrizB[indiceMaxB];
            matrizB[indiceMaxB] = temp;
        }

        // Mostrar las matrices modificadas
        resultado = "Matriz A modificada:\n";
        for (int i = 0; i < m; i++) {
            resultado += matrizA[i] + " ";
        }
        resultado += "\nMatriz B modificada:\n";
        for (int i = 0; i < n2; i++) {
            resultado += matrizB[i] + " ";
        }

        JOptionPane.showMessageDialog(null, resultado);
    }
}
