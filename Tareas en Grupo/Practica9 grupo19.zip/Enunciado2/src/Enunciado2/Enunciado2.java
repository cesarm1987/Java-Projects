package Enunciado2;

// Grupo 19 POO //

import javax.swing.JOptionPane;

public class Enunciado2 {
    // Clase para representar la información de un profesor.
    static class Profesor {
        String nombre;
        int edad;
        char sexo;

        public Profesor(String nombre, int edad, char sexo) {
            this.nombre = nombre;
            this.edad = edad;
            this.sexo = sexo;
        }
    }

    public static void main(String[] args) {
        obtenerInformacionProfesores(); // Invocamos la función para obtener la información de los profesores.
    }

    // Obtenemos la información de los profesores y calculamos la edad promedio, profesor más joven, profesor más mayor,
    // número de profesoras con edad mayor al promedio y número de profesores con edad menor al promedio.
    public static void obtenerInformacionProfesores() {
        // Gestionamos un arreglo para almacenar los objetos de profesor.
        Profesor[] profesores = new Profesor[5];

        // Solicitamos los datos de cada profesor.
        for (int i = 0; i < 5; i++) {
            String nombre = JOptionPane.showInputDialog("Ingrese el nombre del profesor #" + (i + 1));
            int edad = obtenerEdadValida("Ingrese la edad del profesor #" + (i + 1));
            char sexo = JOptionPane.showInputDialog("Ingrese el sexo del profesor #" + (i + 1)).charAt(0);

            profesores[i] = new Profesor(nombre, edad, sexo);
        }

        // Calculamos la edad promedio de los profesores.
        int sumaEdades = 0;
        for (int i = 0; i < 5; i++) {
            sumaEdades += profesores[i].edad;
        }
        double edadPromedio = (double) sumaEdades / 5;

        // Buscamos al profesor más joven y al profesor más mayor.
        Profesor profesorMasJoven = profesores[0];
        Profesor profesorMasMayor = profesores[0];
        for (int i = 1; i < 5; i++) {
            if (profesores[i].edad < profesorMasJoven.edad) {
                profesorMasJoven = profesores[i];
            }
            if (profesores[i].edad > profesorMasMayor.edad) {
                profesorMasMayor = profesores[i];
            }
        }

        // Contamos el número de profesoras con edad mayor al promedio y el número de profesores con edad menor al promedio.
        int contadorProfesorasMayorPromedio = 0;
        int contadorProfesoresMenorPromedio = 0;
        for (int i = 0; i < 5; i++) {
            if (profesores[i].edad > edadPromedio && profesores[i].sexo == 'F') {
                contadorProfesorasMayorPromedio++;
            }
            if (profesores[i].edad < edadPromedio && profesores[i].sexo == 'M') {
                contadorProfesoresMenorPromedio++;
            }
        }

        // Mostramos los resultados obtenidos.
        String resultado = "Edad promedio del grupo de profesores: " + edadPromedio + "\n"
                + "Nombre del profesor(a) más joven: " + profesorMasJoven.nombre + "\n"
                + "Nombre del profesor(a) con mayor edad: " + profesorMasMayor.nombre + "\n"
                + "Número de profesoras con edad mayor al promedio: " + contadorProfesorasMayorPromedio + "\n"
                + "Número de profesores con edad menor al promedio: " + contadorProfesoresMenorPromedio;

        JOptionPane.showMessageDialog(null, resultado);
    }

    // Método para obtener una edad válida (entero) del usuario.
    public static int obtenerEdadValida(String mensaje) {
        while (true) {
            String input = JOptionPane.showInputDialog(mensaje);
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, ingrese una edad válida (número entero).");
            }
        }
    }
}
