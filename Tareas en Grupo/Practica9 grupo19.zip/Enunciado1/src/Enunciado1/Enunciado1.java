package Enunciado1;

// Grupo 19 POO //

import javax.swing.JOptionPane;

public class Enunciado1 {
    // Agregamos variables de clase para mantener el registro de los números ingresados y las sumas.
    private static int[] numeros = new int[9];
    private static int sumaPositivos = 0;
    private static int sumaNegativos = 0;

    public static void main(String[] args) {
        mostrarMenu(); // Inicia el programa mostrando el menú al usuario.
    }

    // Mostramos un menú con las opciones "Ingresar números", "Mostrar sumas" y "Salir".
    public static void mostrarMenu() {
        int opcionSeleccionada;

        do {
            String[] opciones = { "Ingresar números", "Mostrar sumas", "Salir" };

            opcionSeleccionada = JOptionPane.showOptionDialog(
                null,
                "Seleccione una opción:",
                "Menú",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                opciones,
                opciones[0]
            );

            switch (opcionSeleccionada) {
                case 0:
                    ingresarNumeros(); // Invocamos la función para ingresar los números.
                    break;
                case 1:
                    mostrarSumas(); // Invocamos la función para mostrar las sumas.
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, "Gracias por utilizar nuestro programa"); // Muestra mensaje de despedida.
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida", "Error", JOptionPane.ERROR_MESSAGE);
                    // Mostramos un mensaje de error si se selecciona una opción inválida.
                    break;
            }
        } while (opcionSeleccionada != 2); // Repite el menú hasta que se seleccione "Salir".
    }

    // Solicitamos al usuario ingresar 9 números positivos y/o negativos.
    public static void ingresarNumeros() {
        String mensaje = "Ingrese 9 números positivos y/o negativos:\n";

        for (int i = 0; i < 9; i++) {
            String input = JOptionPane.showInputDialog(mensaje + "Número #" + (i + 1));
            int numero = Integer.parseInt(input);

            // Realizamos un balanceo para asegurarnos de que los números estén entre -100 y 100.
            numero = Math.max(-100, Math.min(100, numero));

            numeros[i] = numero;
        }

        JOptionPane.showMessageDialog(null, "Números ingresados exitosamente.");
    }

    // Mostramos las sumas de los números positivos y negativos ingresados.
    public static void mostrarSumas() {
        // Reiniciamos las sumas para evitar acumular resultados de sumas anteriores.
        sumaPositivos = 0;
        sumaNegativos = 0;

        for (int i = 0; i < 9; i++) {
            if (numeros[i] > 0) {
                sumaPositivos += numeros[i];
            } else if (numeros[i] < 0) {
                sumaNegativos += numeros[i];
            }
        }

        String resultado = "Suma de números positivos: " + sumaPositivos + "\n"
                + "Suma de números negativos: " + sumaNegativos;

        JOptionPane.showMessageDialog(null, resultado);
    }
}
