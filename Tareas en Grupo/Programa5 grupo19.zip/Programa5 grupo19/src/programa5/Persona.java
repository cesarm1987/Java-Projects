/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programa5;

/**
 *
 * @author grupo 19
 */

import javax.swing.JOptionPane;

public class Persona {
    private final String nombre;
    private final int edad;
    private final char sexo;
    private final double peso;
    private final double altura;

    public Persona(String nombre, int edad, char sexo, double peso, double altura) {
        this.nombre = nombre;
        this.edad = edad;
        this.sexo = Character.toUpperCase(sexo); // Convertimos el sexo a mayúsculas para simplificar la validación
        this.peso = peso;
        this.altura = altura;
    }

    public double calcularIMC() {
        double alturaEnMetros = altura / 100.0; // Convertimos altura a metros
        return peso / (alturaEnMetros * alturaEnMetros); // Calculamos el IMC utilizando la fórmula
    }

    public boolean esMayorDeEdad() {
        return edad >= 18; // Devolvemos true si la edad es mayor o igual a 18, de lo contrario, devolver false
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + "\n" +
                "Edad: " + edad + "\n" +
                "Sexo: " + sexo + "\n" +
                "Peso: " + peso + " kg\n" +
                "Altura: " + altura + " cm";
    }

    public static void main(String[] args) {
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre:"); // Solicitamos el nombre
        int edad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la edad:")); // Solicitamos la edad
        char sexo = JOptionPane.showInputDialog("Ingrese el sexo (H/M):").charAt(0); // Solicitamos el sexo
        double peso = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el peso (kg):")); // Solicitamos el peso
        double altura = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la altura (cm):")); // Solicitamos la altura

        Persona persona = new Persona(nombre, edad, sexo, peso, altura); // Creamos un objeto de la clase Persona con los datos proporcionados

        JOptionPane.showMessageDialog(null, persona.toString()); // Mostramos la información de la persona

        double imc = persona.calcularIMC(); // Calculamos el IMC de la persona

        String estado = ""; // Por medio de una variable para almacenar el estado correspondiente al IMC

        // Utilizamos un ciclo for
        String[] estados = {"BAJO PESO", "PESO NORMAL", "SOBREPESO", "OBESIDAD 1", "OBESIDAD 2", "OBESIDAD 3"};
        for (int i = 0; i < estados.length - 1; i++) {
            if (imc < getLimiteSuperior(i)) {
                estado = estados[i];
                break;
            }
        }
        if (estado.equals("")) {
            estado = estados[estados.length - 1];
        }

        JOptionPane.showMessageDialog(null, "IMC: " + imc + "\nEstado: " + estado); // Mostramos el IMC y el estado correspondiente

        // Utilizamos un ciclo while
        int i = 0;
        estado = "";
        while (i < estados.length) {
            if (imc < getLimiteSuperior(i)) {
                estado = estados[i];
                break;
            }
            i++;
        }
        if (estado.equals("")) {
            estado = estados[estados.length - 1];
        }

        JOptionPane.showMessageDialog(null, "IMC: " + imc + "\nEstado: " + estado); // Mostrar el IMC y el estado correspondiente

        // Utilizamos un ciclo do-while
        i = 0;
        estado = "";
        do {
            if (imc < getLimiteSuperior(i)) {
                estado = estados[i];
                break;
            }
            i++;
        } while (i < estados.length);
        if (estado.equals("")) {
            estado = estados[estados.length - 1];
        }

        JOptionPane.showMessageDialog(null, "IMC: " + imc + "\nEstado: " + estado); // Mostrar el IMC y el estado correspondiente
    }

    private static double getLimiteSuperior(int index) {
        double[] limites = {18, 25, 30, 35, 40};
        return limites[index];
    }
}
