package practica11;
import javax.swing.JOptionPane;

//Grupo 19 practica 11 curso POO

public class Jugadores {

    public static void main(String[] args) {
        // Declaración de la matriz para almacenar estadísticas de jugadores
        int[][] matrizEstadisticas = new int[3][11];

        // Ciclo para recoger las estadísticas de cada jugador
        for (int i = 2; i < 3; i++) { // El valor de i es 2 (por lo que solo se ejecuta una vez)
            for (int j = 0; j < 11; j++) {
                // Solicitar las estadísticas al usuario
                String pasesGolCorrectosStr = JOptionPane.showInputDialog("Ingrese la cantidad de pases a gol correctos para el jugador " + (j + 1));
                int pasesGolCorrectos = Integer.parseInt(pasesGolCorrectosStr);

                String pasesNormalesStr = JOptionPane.showInputDialog("Ingrese la cantidad de pases normales para el jugador " + (j + 1));
                int pasesNormales = Integer.parseInt(pasesNormalesStr);

                String pasesEquivocadosStr = JOptionPane.showInputDialog("Ingrese la cantidad de pases equivocados para el jugador " + (j + 1));
                int pasesEquivocados = Integer.parseInt(pasesEquivocadosStr);

                // Calcular la puntuación del jugador
                int puntuacion = (pasesGolCorrectos * 5) + (pasesNormales * 1) + (pasesEquivocados * -2);
                matrizEstadisticas[i][j] = puntuacion;
            }
        }

        // Calcular el puntaje total por jugador
        int[] puntosPorJugador = new int[11];
        
        for (int j = 0; j < 11; j++) {
            int puntuacionTotal = matrizEstadisticas[0][j] + matrizEstadisticas[1][j] + matrizEstadisticas[2][j];
            puntosPorJugador[j] = puntuacionTotal;
        }

        // Encontrar el mejor y peor jugador
        int mejorJugador = -1;
        int peorJugador = -1;
        int mejorPuntuacion = Integer.MIN_VALUE;
        int peorPuntuacion = Integer.MAX_VALUE;

        for (int j = 0; j < 11; j++) {
            int puntuacion = puntosPorJugador[j];

            // Actualizar el mejor jugador si se encuentra una puntuación mayor
            if (puntuacion > mejorPuntuacion) {
                mejorPuntuacion = puntuacion;
                mejorJugador = j + 1;
            }

            // Actualizar el peor jugador si se encuentra una puntuación menor
            if (puntuacion < peorPuntuacion) {
                peorPuntuacion = puntuacion;
                peorJugador = j + 1;
            }
        }

        // Crear una representación de los puntos por jugador en forma de cadena
        StringBuilder puntosPorJugadorStr = new StringBuilder();
        for (int j = 0; j < 11; j++) {
            puntosPorJugadorStr.append("Jugador ").append(j + 1).append(": ").append(puntosPorJugador[j]).append(" puntos\n");
        }

        // Mostrar los resultados en una ventana emergente
        JOptionPane.showMessageDialog(null, "Mejor jugador del partido: Jugador " + mejorJugador +
                "\nPeor jugador del partido: Jugador " + peorJugador +
                "\n\nPuntos por jugador:\n" + puntosPorJugadorStr);
    }
}
