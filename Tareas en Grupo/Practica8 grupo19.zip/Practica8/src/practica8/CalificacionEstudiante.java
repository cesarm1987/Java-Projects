package practica8;

/**
 *
 * @author Grupo19
 */
import javax.swing.JOptionPane;

public class CalificacionEstudiante {
    public static void main(String[] args) {
        // Solicitamos al usuario el número de estudiantes
        int cantidadAlumnos = Integer.parseInt(JOptionPane.showInputDialog("¿Cuántos estudiantes hay en el salón?"));

        // Creamos un vector de objetos Estudiante
        Estudiante[] estudiantes = new Estudiante[cantidadAlumnos];

        // Realizamos un ciclo para ingresar las calificaciones de cada estudiante
        for (int i = 0; i < cantidadAlumnos; i++) {
            // Solicitamos al usuario la calificación del estudiante actual
            int nota = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la nota del estudiante " + (i+1) + ":"));
            estudiantes[i] = new Estudiante(nota); // Crear un objeto Estudiante y almacenarlo en el vector
        }

        double promedio = calcularPromedio(estudiantes); // Calcular el promedio de las calificaciones

        String notasSuperiores = obtenerNotasSuperiores(estudiantes, promedio); // Obtener las calificaciones superiores al promedio
        JOptionPane.showMessageDialog(null, "Notas superiores al promedio:\n" + notasSuperiores);

        validarAprobacion(estudiantes); // Validar el estado de aprobación/reprobación de cada estudiante
    }

    public static double calcularPromedio(Estudiante[] estudiantes) {
        double suma = 0;

        for (Estudiante estudiante : estudiantes) {
            suma += estudiante.getNota();
        }

        return suma / estudiantes.length;
    }

    public static String obtenerNotasSuperiores(Estudiante[] estudiantes, double promedio) {
        StringBuilder sb = new StringBuilder();

        for (Estudiante estudiante : estudiantes) {
            if (estudiante.getNota() > promedio) {
                sb.append("Nota: ").append(estudiante.getNota()).append("\n");
            }
        }

        return sb.toString();
    }

    public static void validarAprobacion(Estudiante[] estudiantes) {
        StringBuilder sb = new StringBuilder();

        for (Estudiante estudiante : estudiantes) {
            sb.append("Estudiante: ").append(estudiante.getNota()).append(" - ");

            if (estudiante.getNota() >= 70) {
                sb.append("Aprobado");
            } else if (estudiante.getNota() >= 60) {
                sb.append("Ampliación");
            } else {
                sb.append("Reprobado");
            }

            sb.append("\n");
        }

        JOptionPane.showMessageDialog(null, "Estado de los estudiantes:\n" + sb.toString());
    }
}
