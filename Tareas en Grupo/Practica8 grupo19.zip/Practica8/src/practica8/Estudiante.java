package practica8;

/**
 *
 * @author grupo19
 */

public class Estudiante {
    private int nota;

    public Estudiante(int nota) {
        this.nota = nota;
    }

    public int getNota() {
        return nota;
    }
}
