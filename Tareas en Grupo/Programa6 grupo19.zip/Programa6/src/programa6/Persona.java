//Practica6
package programa6;

/**
 *
 * @author Grupo19
 */

import javax.swing.JOptionPane;

public class Persona {
    private String nombre;
    private int edad;
    private char sexo;
    private double peso;
    private double altura;
    private String dni;

    private static final char SEXO_POR_DEFECTO = 'H';

    public Persona() {
        this.nombre = "";
        this.edad = 0;
        this.sexo = SEXO_POR_DEFECTO;
        this.peso = 0.0;
        this.altura = 0.0;
        this.dni = generarDNI();
    }

    public Persona(String nombre, int edad, char sexo) {
        this.nombre = nombre;
        this.edad = edad;
        this.sexo = Character.toUpperCase(sexo);
        this.peso = 0.0;
        this.altura = 0.0;
        this.dni = generarDNI();
    }

    public Persona(String nombre, int edad, char sexo, double peso, double altura) {
        this.nombre = nombre;
        this.edad = edad;
        this.sexo = Character.toUpperCase(sexo);
        this.peso = peso;
        this.altura = altura;
        this.dni = generarDNI();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = Character.toUpperCase(sexo);
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public String getDni() {
        return dni;
    }

    // Genera un número de DNI aleatorio y lo combina con la letra correspondiente
    private String generarDNI() {
        int numero = (int) (Math.random() * 90000000) + 10000000;
        String letras = "TRWAGMYFPDXBNJZSQVHLCKE";
        char letra = letras.charAt(numero % 23);
        return Integer.toString(numero) + letra;
    }

    // Calcula el índice de masa corporal (IMC) de la persona
    public double calcularIMC() {
        double alturaEnCm = altura / 100; // La altura se mantiene en centímetros
        double alturaCuadradaEnCm = Math.pow(alturaEnCm, 2);
        return peso / alturaCuadradaEnCm;
    }
    // Verifica si la persona es mayor de edad
    public boolean esMayorDeEdad() {
        if (sexo == 'H') {
            return edad >= 18;
        } else {
            return edad >= 21;
        }
    }

    // Comprueba que el género sea válido y lo devuelve en mayúsculas
    private char comprobarGenero(char sexo) {
        sexo = Character.toUpperCase(sexo);
        if (sexo == 'H' || sexo == 'M') {
            return sexo;
        } else {
            return SEXO_POR_DEFECTO;
        }
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + "\n" +
                "Edad: " +

 edad + "\n" +
                "Sexo: " + sexo + "\n" +
                "Peso: " + peso + " kg\n" +
                "Altura: " + altura + " cm\n" +
                "DNI: " + dni;
    }

    public static void main(String[] args) {
        // Solicitar datos al usuario utilizando JOptionPane
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre:");
        int edad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la edad:"));
        char sexo = JOptionPane.showInputDialog("Ingrese el sexo (H/M):").charAt(0);
        double peso = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el peso (kg):"));
        double altura = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la altura (cm):"));

        // Crear objetos de la clase Persona con los datos proporcionados
        Persona persona1 = new Persona(nombre, edad, sexo, peso, altura);
        Persona persona2 = new Persona(nombre, edad, sexo);
        Persona persona3 = new Persona();

        // Mostrar información de la persona 1 utilizando JOptionPane
        JOptionPane.showMessageDialog(null, "Información de la persona 1:\n" +
                persona1.toString());
        double imcPersona1 = persona1.calcularIMC();
        String estadoPersona1 = getEstadoSalud(imcPersona1);
        JOptionPane.showMessageDialog(null, "IMC: " + imcPersona1 + "\nEstado: " + estadoPersona1);
        JOptionPane.showMessageDialog(null, "¿Es mayor de edad? " + (persona1.esMayorDeEdad() ? "Sí" : "No"));

        // Mostrar información de la persona 2 utilizando JOptionPane
        JOptionPane.showMessageDialog(null, "Información de la persona 2:\n" +
                persona2.toString());
        double imcPersona2 = persona2.calcularIMC();
        String estadoPersona2 = getEstadoSalud(imcPersona2);
        JOptionPane.showMessageDialog(null, "IMC: " + imcPersona2 + "\nEstado: " + estadoPersona2);
        JOptionPane.showMessageDialog(null, "¿Es mayor de edad? " + (persona2.esMayorDeEdad() ? "Sí" : "No"));

        // Mostrar información de la persona 3 utilizando JOptionPane
        JOptionPane.showMessageDialog(null, "Información de la persona 3:\n" +
                persona3.toString());
        double imcPersona3 = persona3.calcularIMC();
        String estadoPersona3 = getEstadoSalud(imcPersona3);
        JOptionPane.showMessageDialog(null, "IMC: " + imcPersona3 + "\nEstado: " + estadoPersona3);
        JOptionPane.showMessageDialog(null, "¿Es mayor de edad? " + (persona3.esMayorDeEdad() ? "Sí" : "No"));
    }

    // Devuelve el estado de salud según el IMC proporcionado
    private static String getEstadoSalud(double imc) {
        if (imc < 18.5) {
            return "Bajo peso";
        } else if (imc < 24.9) {
            return "Peso normal";
        } else if (imc < 29.9) {
            return "Sobrepeso";
        } else if (imc < 34.9) {
            return "Obesidad grado 1";
        } else if (imc < 39.9) {
            return "Obesidad grado 2";
        } else {
            return "Obesidad grado 3";
        }
    }
}
